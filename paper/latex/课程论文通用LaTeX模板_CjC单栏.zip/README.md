# 中文课程论文 LaTeX 通用模板

本工程把当前课程论文采用的中文单栏 CjC 排版配置整理成可复用模板。它提供 A4 单栏页面、页眉页脚、中文与英文摘要、章节模块、数学公式、图表及数字编号参考文献的基础结构。论文内容、图片和作者信息均为占位内容。

## Overleaf 使用

1. 选择 **New Project → Upload Project**，上传本目录中的 ZIP。
2. 在 **Menu → Compiler** 选择 **XeLaTeX**。
3. 主文件使用根目录的 `main.tex`，点击 Recompile。
4. 先编辑 `config/metadata.tex`，再替换 `main.tex` 的中英文摘要和关键词，以及 `sections/` 下的章节内容。

ZIP 使用 Overleaf 项目根目录结构：`main.tex`、`CjC.cls`、依赖样式文件和 `references.bib` 位于根目录，其他源码位于对应子目录。`CjC.cls` 与主文件同级，因此不需要额外设置 TeX 搜索路径。

## Windows 本地编译

在 PowerShell 中进入解压后的项目目录并运行：

    .\build\build.ps1

需要 XeLaTeX、BibTeX 以及 CTeX、AMS 等宏包。模板默认不带虚构参考文献。需要引用文献时，在 `references.bib` 添加真实条目，并在 `main.tex` 末尾取消注释参考文献标题、`\bibliographystyle` 与 `\bibliography` 三行；正文引用使用 `\cite{citation_key}`。构建脚本会根据已启用的参考文献和正文引用自动运行 BibTeX。

## 内容修改位置

- 作者、学号、学院、专业、课程、教师、日期和页眉：`config/metadata.tex`。
- 页面、字体、摘要间距、公式和图表样式：`config/style.tex`、`config/layout.tex`。
- 中英文摘要、关键词和章节顺序：`main.tex`。
- 五个示例章节：`sections/`。可按课程要求增删文件，并同步调整 `main.tex` 中的 `\input{...}`。
- 代码与数据、生成式人工智能说明：`backmatter/declarations.tex`。请据实填写；不适用时可删除相应小节。
- 参考文献：`references.bib`。添加真实文献条目，并在正文使用 `\cite{citation_key}`；未核验或未引用的示例文献不要保留。
- 图片：放入 `figures/`，使用相对路径引用，例如 `\includegraphics[width=0.8\textwidth]{figure-name.pdf}`。

模板保留了五章示例，但章节标题和数量都可以修改，不是固定的课程结构。

## 默认排版

A4 纵向、单栏；正文约 11 pt、约 1.25 倍行距；摘要与关键词使用窄于正文的版心；公式连续编号；图表自动编号；西文字体为 TeX Gyre Termes，中文字体由 CTeX 按系统选择。页面尺寸、页眉高度和间距可在 `config/layout.tex` 调整。

## 模板来源与许可

模板来源、保留的上游文件及许可状态见 `TEMPLATE_NOTICE.md`。此工程适合本地课程论文复用；若要将包含 `CjC.cls` 及其依赖的模板再次公开发布，请先核对各文件的授权条件。

